package br.edu.ifsul.bcc.too.topico5.exercicios.estudo_caso_agenciabilhetes.diagrama;

/**
 *
 * @author Usuario
 */
public abstract class Bilhete {
    
    private Long id;
    private Integer numero;
    private String assento;
    
    Bilhete(){
        
    }
    
    public Bilhete(Long id,
                    Integer numero,
                    String assento){
        
        this.id = id;
        this.numero = numero;
        this.assento = assento;
    }
    
    
}
