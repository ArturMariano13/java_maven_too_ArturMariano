package br.edu.ifsul.bcc.too.topico5.exercicios.estudo_caso_agenciabilhetes.diagrama;

import java.util.Date;
import java.util.Collection;

/**
 *
 * @author Usuario
 */
public class Horario {
    
    private Long id;
    private String codigo;
    private Date partida;
    private Date chegada;
    private Integer qtdEconomica;
    private Integer qtdPrimeira;
    private Integer qtdExecutiva;
    private Aviao aviao;
    private Collection <Bilhete> bilhete;

    public Horario() {
    }

    public Horario(Long id, 
                String codigo, 
                Date partida, 
                Date chegada, 
                Integer qtdEconomica, 
                Integer qtdPrimeira, 
                Integer qtdExecutiva, 
                Aviao aviao) {
        this.id = id;
        this.codigo = codigo;
        this.partida = partida;
        this.chegada = chegada;
        this.qtdEconomica = qtdEconomica;
        this.qtdPrimeira = qtdPrimeira;
        this.qtdExecutiva = qtdExecutiva;
        this.aviao = aviao;
    }
    
    
}
