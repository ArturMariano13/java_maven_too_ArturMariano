/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsul.bcc.too.topico5.exercicios.estudo_caso_agenciabilhetes.diagrama;

/**
 *
 * @author Usuario
 */
public class Endereco {
    
    private Long id;
    private String rua;
    private Integer numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private String pais;
    
    Endereco(){
        
    }
    
    public Endereco(Long id,
                    String rua,
                    Integer numero,
                    String complemento,
                    String bairro,
                    String cidade,
                    String estado,
                    String pais){
        
        this.id = id;
        this.rua = rua;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.pais = pais;
    }
}
