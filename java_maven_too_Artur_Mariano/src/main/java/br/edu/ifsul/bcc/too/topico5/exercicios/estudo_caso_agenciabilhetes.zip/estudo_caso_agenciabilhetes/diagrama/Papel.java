/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsul.bcc.too.topico5.exercicios.estudo_caso_agenciabilhetes.diagrama;

/**
 *
 * @author Usuario
 */
public class Papel {
    
    private Long id;
    private String nome;
    private String descricao;
    
    Papel(){
        
    }
    
    public Papel(Long id,
                String nome,
                String descricao){
        
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
    }
}
