/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsul.bcc.too.topico5.exercicios.estudo_caso_agenciabilhetes.diagrama;

import java.util.Collection;

/**
 *
 * @author Usuario
 */
public class CiaAerea {
    
    private Long id;
    private String nome;
    private Collection<Rota> rotas;
    private Collection<Aviao> avioes;
    private Collection<Papel> papeis;
    
    CiaAerea(){
        
    }

    public CiaAerea(Long id, String nome, Collection<Rota> rotas, Collection<Aviao> avioes, Collection<Papel> papeis) {
        this.id = id;
        this.nome = nome;
        this.rotas = rotas;
        this.avioes = avioes;
        this.papeis = papeis;
    }

    public Long getId() {
        return id;
    }

    public Collection<Aviao> getAvioes() {
        return avioes;
    }

    public String getNome() {
        return nome;
    }

    public Collection<Papel> getPapeis() {
        return papeis;
    }

    public Collection<Rota> getRotas() {
        return rotas;
    }

    public void setRotas(Collection<Rota> rotas) {
        this.rotas = rotas;
    }

    public void setPapeis(Collection<Papel> papeis) {
        this.papeis = papeis;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAvioes(Collection<Aviao> avioes) {
        this.avioes = avioes;
    }

    public void setId(Long id) {
        this.id = id;
    }   
}
